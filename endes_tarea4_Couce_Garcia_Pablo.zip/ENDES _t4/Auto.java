package Auto;

import java.util.ArrayList;

/**
 * La clase Car representa un automovil con propiedades basicas y metodos
 * para acceder y modificar sus propiedades
 *
 * @author  Pablo
 * @version 1.0
 * @since 2024-02-05
 */


public class Auto {

    /**
     * Marca del automovil
     */
    private String marca;

    /**
     * modelo del automovil
     */
    private String modelo;

    /**
     *
     * @param marca La marca del automovil
     * @param modelo El modelo del automovil
     */
    public Auto(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }

    /**
     * Obtienes la marca del automovil
     * @return la marca del automovil
     */
    public String getMarca() {
        return marca;
    }

    /**
     * Establece la marca del automovil
     * @param marca marca del automovil
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * Obtienes el modelo del automovil
     * @return el modelo del automovil
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * Establece el modelo del automovil
     * @param modelo modelo del automovil
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Muestra todos las caracteristicas del automovil
     */
    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + "]";
    }
}
