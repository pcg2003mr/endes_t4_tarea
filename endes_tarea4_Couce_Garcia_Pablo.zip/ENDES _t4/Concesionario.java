package Concesionario;

import java.util.ArrayList;
import Auto.Auto;

/**
 * La clase Concesionario representa una lista de automoviles con metodos
 * para acceder y modificar sus propiedades
 *
 * @author  Pablo
 * @version 1.0
 * @since 2024-02-05
 */

public class Concesionario {

    /**
     * Lista de automoviles
     */
    private ArrayList<Auto> autos;

    /**
     *
     * Constructor vacio de la lista de automoviles
     */
    public Concesionario() {
        autos = new ArrayList<>();
    }

    /**
     * Agrega un automovil a la lista
     * @param auto un automovil
     */
    public void agregarAuto(Auto auto) {
        autos.add(auto);
    }

    /**
     * EInicializa la lista de automoviles
     * @return la lista de automoviles
     */
    public ArrayList<Auto> listarAutos() {
        return autos;
    }

    /**
     * Imprime por pantalla la lista de automoviles
     */
    public void imprimirAutos(){
        for (Auto auto: autos){
            System.out.println(auto);
        }
    }
}
